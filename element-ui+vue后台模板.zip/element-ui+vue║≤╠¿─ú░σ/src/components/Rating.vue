<template>
  <div class="rating">
    我是评价
  </div>
</template>
<script>
export default {
}
</script>
<style>

</style>
