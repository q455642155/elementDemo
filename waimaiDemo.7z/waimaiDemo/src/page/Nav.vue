<template>
  <div class="nav">
    <div class="navItem">
      <router-link to='/goods' enter-link-class="active">商品</router-link>
    </div>
    <div class="navItem">
      <router-link to='/rating' enter-link-class="active">评价</router-link>
    </div>
    <div class="navItem">
      <router-link to='/seller' enter-link-class="active">商家</router-link>
    </div>
  </div>
</template>
<script>
export default {}
</script>
<style lang="scss">
.nav {
  display: flex;
  width: 100%;
  height: 40px;
  line-height: 40px;
  text-align: center;
  border-top: 1px solid #eee;
  border-bottom: 1px solid #eee;
  .navItem {
    flex: 1;
    a {
      display: block;
      color: #666;
      &.active {
        color: #f00;
      }
    }
  }
}
</style>
