<template>
  <div class="header">
    <div class="content-wrapper">
      <div class="avatar">
        <img :src="seller.avatar" width="64" height="64" alt="">
      </div>
      <div class="content">
        <div class="title">
          <span class="brand"></span>
          <span class="name">{{seller.name}}</span>
        </div>
        <div class="description">
          <span>{{seller.description}}/{{seller.deliveryTime}}分钟送达</span>
        </div>
        <div class="support" v-if="seller.supports">
          <span class="icon" :class="classMap[seller.supports[0].type]"></span>
          <span class="text">{{seller.supports[0].description}}</span>
        </div>
      </div>
      <div v-if="seller.supports" class="supportCount" @click="showSellerDetail">
        <span class="count">{{seller.supports.length}}个</span>
        <i class="icon-keyboard_arrow_right"></i>
      </div>
    </div>
    <div class="bulletin-wrapper" @click="showSellerDetail">
      <span class="bulletin-title"></span>
      <span class="bulletin-text">{{seller.bulletin}}</span>
      <i class="icon-keyboard_arrow_right"></i>
    </div>
    <!--头部背景图片-->
    <div class="bg">
      <img :src="seller.avatar" width="100%" height="100%" alt="">
    </div>
    <!--商家信息弹出详情-->
    <transition name="fade" enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
      <detail-view :sellerDetail="seller" :visible.sync="showDetail" v-show="showDetail"></detail-view>
    </transition>
  </div>
</template>
<script>
import DetailView from '../components/SellerDetail'
export default {
  data () {
    return {
      showDetail: false,
      seller: {} // 商家信息
    }
  },
  components: {
    DetailView
  },
  created () {
    this.classMap = ['decrease', 'discount', 'special', 'invoice', 'guarantee']
  },
  mounted () {
    this.axios.get('/api/seller').then(res => {
      console.log(res.data.data)
      if (res.data.status) {
        this.seller = res.data.data
      }
    }).catch(err => {
      console.log(err)
    })
  },
  methods: {
    showSellerDetail () {
      this.showDetail = true
    }
  }
}
</script>
<style lang="scss">
@import '../assets/css/icon.css';
@import '../assets/css/mixin.scss';
.header {
  position: relative;
  color:#fff;
  background: rgba(7, 17, 27, 0.5);
  .content-wrapper {
    position: relative;
    padding: 24px 12px 18px 24px;
    font-size: 0;
    .avatar {
      display: inline-block;
      vertical-align: top;
      img {
        border-radius: 4px;
      }
    }
    .content {
      display: inline-block;
      vertical-align: top;
      margin-left: 16px;
      .title {
        margin: 2px 0 8px 0;
        .brand {
          display: inline-block;
          vertical-align: top;
          width: 30px;
          height: 18px;
          @include bg-image('../assets/images/brand');
          background-size: 30px 18px;
          background-repeat: no-repeat;
        }
        .name {
          display: inline-block;
          margin-left: 6px;
          font-size: 16px;
          line-height: 18px;
          font-weight: 700;
        }
      }
      .description {
        margin-bottom:10px;
        font-size: 12px;
        line-height: 12px;
      }
      .support {
        .icon {
          display: inline-block;
          vertical-align: top;
          width: 12px;
          height: 12px;
          margin-right: 4px;
          background-size: 12px 12px;
          background-repeat: no-repeat;
          &.decrease {
            @include bg-image('../assets/images/decrease_1');
          }
          &.discount {
            @include bg-image('../assets/images/discount_1');
          }
          &.guarantee {
            @include bg-image('../assets/images/guarantee_1');
          }
          &.invoice {
            @include bg-image('../assets/images/invoice_1');
          }
          &.special {
            @include bg-image('../assets/images/special_1');
          }
        }
        .text {
          line-height: 12px;
          font-size: 10px;
        }
      }
    }
    .supportCount {
      position: absolute;
      right: 12px;
      bottom: 14px;
      padding: 7px 8px;
      border-radius: 14px;
      background: rgba(0, 0, 0, 0.2);
      text-align: center;
      .count {
        font-size: 10px;
      }
      .icon-keyboard_arrow_right {
        margin-left: 2px;
        font-size: 10px;
      }
    }
  }
  .bulletin-wrapper {
    position: relative;
    padding: 0 22px 0 12px;
    height: 28px;
    line-height: 28px;
    overflow: hidden;
    background: rgba(7, 17, 27, 0.2);
    white-space: nowrap;
    text-overflow: ellipsis;
    .bulletin-title {
      display: inline-block;
      vertical-align: top;
      width: 22px;
      height: 12px;
      margin-top: 8px;
      @include bg-image('../assets/images/bulletin');
      background-size: 22px 12px;
      background-repeat: no-repeat;
    }
    .bulletin-text {
      vertical-align: top;
      font-size: 10px;
    }
    .icon-keyboard_arrow_right {
      position: absolute;
      top: 9px;
      right: 12px;
      font-size: 10px;
    }
  }
  .bg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    filter: blur(10px);
  }
}
</style>
