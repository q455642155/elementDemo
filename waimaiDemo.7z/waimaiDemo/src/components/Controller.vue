<template>
  <div class="controller">
    <transition name="fade" enter-active-class="animated fadeIn" leave-active-class="animated fadeOut">
      <div class="cart-decrease" @click="decreaseCart($event)" v-show="this.food.count > 0">
        <span class="inner icon-remove_circle_outline"></span>
      </div>
    </transition>
    <div class="cart-count" v-show="this.food.count > 0">{{this.food.count}}</div>
    <div class="cart-add icon-add_circle" @click="addCart($event)"></div>
  </div>
</template>
<script>
// import Vue from 'vue'
export default {
  props: ['food'],
  data () {
    return {
      num: 0,
      goodList: []
    }
  },
  methods: {
    addCart (e) {
      this.num++
      this.$store.commit('getGoodsNumber', 1)
    },
    decreaseCart (e) {
      this.num--
      this.$store.commit('getGoodsNumber', 1)
      console.log(this.num)
    }
  }
}
</script>
<style lang="scss">
.controller {
  font-size: 0;
  .cart-decrease {
    display: inline-block;
    padding: 6px;
    .inner {
      display: inline-block;
      line-height: 24px;
      font-size: 24px;
      color: rgb(0, 160, 220);
    }
  }
  .cart-count {
    display: inline-block;
    vertical-align: top;
    width: 12px;
    padding-top: 6px;
    line-height: 24px;
    text-align: center;
    font-size: 10px;
    color: rgb(147, 153, 159);
  }
  .cart-add {
    display: inline-block;
    padding: 6px;
    line-height: 24px;
    font-size: 24px;
    color: rgb(0, 160, 220);
  }
}
</style>
