<template>
  <div class="app-nav-wrap">
    <el-menu :default-active="$route.path" class="el-menu-vertical-demo" router>
        <el-menu-item v-for="menu in menus" :index="menu.route" :key="menu.route" v-if="!menu.children">
            <i class="el-icon-menu"></i>{{menu.name}}
        </el-menu-item>
        <el-submenu v-for="menu in menus" :index="menu.route" :key="menu.route" v-if="menu.children">
            <template slot="title"><i class="el-icon-menu"></i>{{menu.name}}</template>
            <el-menu-item :index="item.route" v-for="item in menu.children" :key="item.route"> <i class="el-icon-location"></i>{{item.name}}</el-menu-item>
        </el-submenu>
    </el-menu>
  </div>
</template>

<style>
</style>

<script>
export default {
  data () {
    return {
      menus: [
        { route: '/', name: '首页', children: false },
        { route: '/user', name: '用户管理', children: false },
        { route: '/userInfo', name: '用户详情页', children: false },
        {
          route: '/perform',
          name: '绩效考核',
          children: [
            { route: '/month', name: '月度绩效' },
            { route: '/year', name: '年度绩效' }
          ]
        }
      ]
    }
  }
}
</script>
