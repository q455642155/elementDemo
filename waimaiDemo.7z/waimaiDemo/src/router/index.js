import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '../page/Index.vue'
import Good from '../components/Goods.vue'
import Rating from '../components/Rating.vue'
import Seller from '../components/Seller.vue'
Vue.use(VueRouter)
export default new VueRouter({
  mode: 'history',
  linkActiveClass: 'active',
  routes: [
    {
      path: '/',
      component: Index,
      children: [
        {
          path: '/',
          redirect: '/goods'
        },
        {
          path: '/goods',
          component: Good
        },
        {
          path: '/rating',
          component: Rating
        },
        {
          path: '/seller',
          component: Seller
        }
      ]
    }
  ]
})
