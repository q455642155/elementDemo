import Vue from 'vue'
import VueRouter from 'vue-router'
import Main from '@/page/Main'
import ElementTable from '@/page/ElementTable'
import DetailInfo from '@/page/DetailInfo'
import Template from '@/page/Template'
import Monthform from '@/page/MonthForm'
import Theform from '@/page/TheForm'
Vue.use(VueRouter)
export default new VueRouter({
  mode: 'history',
  linkActiveClass: 'active',
  routes: [
    {
      path: '/',
      name: '首页',
      component: Main,
      children: [
        {
          path: '/user',
          name: '用户管理',
          component: ElementTable
        },
        {
          path: '/userInfo',
          name: '用户详情页',
          component: DetailInfo
        },
        {
          path: '/perform',
          name: '绩效考核',
          component: Template,
          children: [
            {
              path: '/month',
              name: '月度绩效',
              component: Monthform
            },
            {
              path: '/year',
              name: '年度绩效',
              component: Theform
            }
          ]
        }
      ]
    },
    {
      path: '*',
      redirect: '/'
    }
  ]
})
