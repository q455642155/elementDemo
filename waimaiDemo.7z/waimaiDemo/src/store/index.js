import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    goodsNumber: 0,
    goodsTotalPrice: 0,
    goodList: []
  },
  mutations: {
    getGoodsNumber (state, data) {
      state.goodsNumber += data
    },
    getGoodsPrice (state, data) {
      state.goodsTotalPrice += data
    }
  }
})
