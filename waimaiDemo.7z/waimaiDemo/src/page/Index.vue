<template>
    <div class="index">
        <header-view></header-view>
        <nav-view></nav-view>
        <router-view></router-view>
        <!--购物车-->
        <cart-view></cart-view>
    </div>
</template>
<script>
import HeaderView from './Header.vue'
import NavView from './Nav.vue'
import CartView from '../components/Cart.vue'
export default {
  components: {
    HeaderView,
    NavView,
    CartView
  }
}
</script>
<style>

</style>
