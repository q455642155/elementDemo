<template>
  <div class="detail">
    <div class="detail-wrapper clearfix">
      <div class="detail-main">
        <h1 class="name">{{sellerDetail.name}}</h1>
        <div class="star-wrapper">
          <star-view :size="48" :score="sellerDetail.score"></star-view>
        </div>
        <div class="title">
          <div class="line"></div>
          <div class="text">优惠信息</div>
          <div class="line"></div>
        </div>
        <ul v-if="sellerDetail.supports" class="supports">
          <li class="support-item" v-for="(item,index) in sellerDetail.supports" :key="index">
            <span class="icon" :class="classMap[sellerDetail.supports[index].type]"></span>
            <span class="text">{{sellerDetail.supports[index].description}}</span>
          </li>
        </ul>
        <div class="title">
          <div class="line"></div>
          <div class="text">商家公告</div>
          <div class="line"></div>
        </div>
        <div class="bulletin">
          <p class="content">{{sellerDetail.bulletin}}</p>
        </div>
      </div>
    </div>
    <div class="detail-close" @click="close">
      <i class="icon-close"></i>
    </div>
  </div>
</template>
<script>
import StarView from './Star'
export default {
  props: ['sellerDetail', 'visible'],
  components: {
    StarView
  },
  created () {
    this.classMap = ['decrease', 'discount', 'special', 'invoice', 'guarantee']
  },
  methods: {
    close () {
      this.$emit('update:visible', false)
    }
  }
}
</script>
<style lang="scss">
@import '../assets/css/base.scss';
@import '../assets/css/mixin.scss';
.detail {
  position: fixed;
  top: 0;
  left: 0;
  z-index: 999;
  width: 100%;
  height: 100%;
  overflow: auto;
  background: rgba(7, 17, 27, 0.8);
  .detail-wrapper {
    width: 100%;
    min-height: 100%;
    .detail-main {
      margin-top: 64px;
      padding-bottom: 64px;
      .name {
        line-height: 16px;
        font-size: 16px;
        text-align: center;
      }
      .star-wrapper {
        margin-top: 18px;
        padding: 2px 0;
        text-align: center;
      }
      .title {
        display: flex;
        width: 80%;
        margin: 28px auto 24px auto;
        .line {
          flex: 1;
          position: relative;
          top: -6px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        .text {
          padding: 0 12px;
          font-weight: 700;
          font-size: 14px;
        }
      }
      .supports {
        width: 80%;
        margin: 0 auto;
        .support-item {
          padding: 0 12px;
          margin-bottom: 12px;
          &:last-child {
            margin-bottom: 0;
          }
          .icon {
            display: inline-block;
            vertical-align: top;
            width: 16px;
            height: 16px;
            margin-right: 6px;
            background-size: 16px 16px;
            background-repeat: no-repeat;
            &.decrease {
              @include bg-image('../assets/images/decrease_2');
            }
            &.discount {
              @include bg-image('../assets/images/discount_2');
            }
            &.guarantee {
              @include bg-image('../assets/images/guarantee_2');
            }
            &.invoice {
              @include bg-image('../assets/images/invoice_2');
            }
            &.special {
              @include bg-image('../assets/images/special_2');
            }
          }
          .text {
            line-height: 16px;
            font-size: 12px;
          }
        }
      }
      .bulletin {
        width: 80%;
        margin: 0 auto;
        .content {
          font-size: 12px;
          font-weight: 200;
          line-height: 24px;
          text-align: justify;
          letter-spacing: 2px;
          color: #fff;
        }
      }
    }
  }
  .detail-close {
    position: relative;
    margin: -64px auto 0 auto;
    width: 32px;
    height: 32px;
    clear: both;
    font-size: 32px;
  }
}
</style>
