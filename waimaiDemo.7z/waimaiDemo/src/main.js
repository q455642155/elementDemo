import 'es5-shim'
import Vue from 'vue'
import App from './App'
import router from './router'
import 'animate.css'
import axios from 'axios'
import VueAxios from 'vue-axios'
import { monitorInit } from '@/monitorDatas'
import preview from 'vue-photo-preview'
import 'vue-photo-preview/dist/skin.css'
import store from './store'
Vue.use(preview)// 图片预览
if (process.env.NODE_ENV === 'development') {
  monitorInit() // 模拟数据初始化
}
Vue.use(VueAxios, axios)
Vue.config.productionTip = false
// Vue.use(ElementUI)
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: {
    App
  },
  template: '<App/>'
})
